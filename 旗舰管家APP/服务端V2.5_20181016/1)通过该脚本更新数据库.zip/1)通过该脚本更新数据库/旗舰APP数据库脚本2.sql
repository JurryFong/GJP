SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE procedure DJCX
@currPage int = 1,   --->��ǰҳҳ��(��top currPage)  
@strCondition varchar(2000) ='', --->��ѯ����(��where condition......) ���ü�where�ؼ���   
@StartData varchar(100)='' , --->��ѯ����(��ʼʱ��)  
@EndData varchar(100)='',--->��ѯ����������ʱ�䣩
@ascColumn varchar(100) = '',  --->������ֶ���(��order by column asc/desc)  
@bitOrderType int = 0,   --->���������(0Ϊ����,1Ϊ����)  
@pkColumn varchar(50) = '',  --->�������� 
@YHNO  varchar(100) ,-->�û��� 
@pageSize int = 20   --->��ҳ��С  
as  

begin  --->�洢���̿�ʼ  
---�ô洢������Ҫ�õ��ļ�������---  
declare @strTemp varchar(1000)  
declare @strSql varchar(8000)  --->�ô洢�������ִ�е����  
declare @strOrderType varchar(1000) --->�����������(order by column asc/desc)  
begin  
if @bitOrderType = 1  --->@bitOrderType = 1 ��ִ�н���  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' desc'  
    set @strTemp = '<(select min'  
end  
else  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' asc'  
    set @strTemp = '>(select max'  
end  
if @currPage = 1 --->����ǵ�һҳ  

begin  
   if @strCondition != ''  

set @strSql ='select top ' + str(@pageSize) + ' '
 + 'sys_doc.id, sys_doc.doc_hao, sys_doc.doc_date,
 case when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''C''' 
+'then''LL'''+' when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''R''' 
+'then''SR'''+' when right(doc_hao,2) =''CH'''
+'then left(doc_hao,len(doc_hao) - 13) 
else left(doc_hao,len(doc_hao) - 11) 
end as doc_kind, sys_doc.client_id, sys_doc.ck_name,
 case when substring(doc_hao,1,2 ) =''CZ'''+' and len(sys_doc.doc_hao ) = 13 
then sys_doc.comment
 +(select case finish_flag when 0 then''�ݸ�'''+' when 1 then''�����'''+' when 2 then ''��������'''+' when 3 then''����ֹ'''+' end from cz where cz_hao = sys_doc.doc_hao)
 else sys_doc.comment end comment , sys_doc.all_money, sys_doc.dis_money, sys_doc.user_name, client.client_name, employee.em_name, 
client.client_pym, employee.em_pym,employee.em_code, bm.bm_name, bm.bm_pym, sys_doc.del_flag, sys_doc.red_flag, sys_doc.ck_id, ck.ck_name, ck.ck_peo, 
sys_doc.js_money , sys_doc.sys_date' + 


' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' 


+ ' where ' + ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '+ @YHNO +')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0' + ' and ' + @strCondition + @strOrderType  
  
  else  

set @strSql = '  select top ' + str(@pageSize) + ' '
 + 'sys_doc.id, sys_doc.doc_hao, sys_doc.doc_date,
 case when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''C''' 
+'then''LL'''+' when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''R''' 
+'then''SR'''+' when right(doc_hao,2) =''CH'''
+'then left(doc_hao,len(doc_hao) - 13) 
else left(doc_hao,len(doc_hao) - 11) 
end as doc_kind, sys_doc.client_id, sys_doc.ck_name,
 case when substring(doc_hao,1,2 ) =''CZ'''+' and len(sys_doc.doc_hao ) = 13 
then sys_doc.comment
 +(select case finish_flag when 0 then''�ݸ�'''+' when 1 then''�����'''+' when 2 then ''��������'''+' when 3 then''����ֹ'''+' end from cz where cz_hao = sys_doc.doc_hao)
 else sys_doc.comment end comment , sys_doc.all_money, sys_doc.dis_money, sys_doc.user_name, client.client_name, employee.em_name, 
client.client_pym, employee.em_pym,employee.em_code, bm.bm_name, bm.bm_pym, sys_doc.del_flag, sys_doc.red_flag, sys_doc.ck_id, ck.ck_name, ck.ck_peo, 
sys_doc.js_money , sys_doc.sys_date' + 


' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' 


+ ' where ' + ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = ' + @YHNO+')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0' + @strOrderType 

end

else 

begin

 if @strCondition != ''  
set @strSql =  'select top ' + str(@pageSize) + ' ' + 
'sys_doc.id, sys_doc.doc_hao, sys_doc.doc_date,
 case when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''C''' 
+'then''LL'''+' when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''R''' 
+'then''SR'''+' when right(doc_hao,2) =''CH'''
+'then left(doc_hao,len(doc_hao) - 13) 
else left(doc_hao,len(doc_hao) - 11) 
end as doc_kind, sys_doc.client_id, sys_doc.ck_name,
 case when substring(doc_hao,1,2 ) =''CZ'''+' and len(sys_doc.doc_hao ) = 13 
then sys_doc.comment
 +(select case finish_flag when 0 then''�ݸ�'''+' when 1 then''�����'''+' when 2 then ''��������'''+' when 3 then''����ֹ'''+' end from cz where cz_hao = sys_doc.doc_hao)
 else sys_doc.comment end comment , sys_doc.all_money, sys_doc.dis_money, sys_doc.user_name, client.client_name, employee.em_name, 
client.client_pym, employee.em_pym,employee.em_code, bm.bm_name, bm.bm_pym, sys_doc.del_flag, sys_doc.red_flag, sys_doc.ck_id, ck.ck_name, ck.ck_peo, 
sys_doc.js_money , sys_doc.sys_date'+

 ' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' +
 ' where ' +  ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '+ @YHNO +')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0'  + ' and ' + @strCondition 

 --+ ' and ' +  
--@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
--' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
--employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
-- JOIN ck ON sys_doc.ck_id = ck.ck_id}' + @strOrderType + ') as TabTemp)' + @strOrderType
  
+ ' and ' + @pkColumn + @strTemp +  
'(' + @pkColumn + ')' + ' from (
select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + 

' from ' +  
'{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' +
 ' where ' +  ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '+ @YHNO +')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0' + ' and ' + @strCondition + @strOrderType + ') as TabTemp)' + @strOrderType  


else

set @strSql = 'select top ' + str(@pageSize) + ' ' + 
'sys_doc.id, sys_doc.doc_hao, sys_doc.doc_date,
 case when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''C''' 
+'then''LL'''+' when substring(doc_hao,1,2 ) =''CZ'''
 +'and len(sys_doc.doc_hao ) > 13 
and substring(sys_doc.doc_hao,14,1) =''R''' 
+'then''SR'''+' when right(doc_hao,2) =''CH'''
+'then left(doc_hao,len(doc_hao) - 13) 
else left(doc_hao,len(doc_hao) - 11) 
end as doc_kind, sys_doc.client_id, sys_doc.ck_name,
 case when substring(doc_hao,1,2 ) =''CZ'''+' and len(sys_doc.doc_hao ) = 13 
then sys_doc.comment
 +(select case finish_flag when 0 then''�ݸ�'''+' when 1 then''�����'''+' when 2 then ''��������'''+' when 3 then''����ֹ'''+' end from cz where cz_hao = sys_doc.doc_hao)
 else sys_doc.comment end comment , sys_doc.all_money, sys_doc.dis_money, sys_doc.user_name, client.client_name, employee.em_name, 
client.client_pym, employee.em_pym,employee.em_code, bm.bm_name, bm.bm_pym, sys_doc.del_flag, sys_doc.red_flag, sys_doc.ck_id, ck.ck_name, ck.ck_peo, 
sys_doc.js_money , sys_doc.sys_date'+

 ' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' +
 ' where ' +  ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '+ @YHNO +')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0'

-- + ' and ' +  
--@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
--' from ' + '{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
--employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
-- JOIN ck ON sys_doc.ck_id = ck.ck_id}' + @strOrderType + ') as TabTemp)' + @strOrderType


+' and ' + @pkColumn + @strTemp +  
'(' + @pkColumn + ')' + ' from (
select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + 

' from ' +  
'{oj sys_doc LEFT OUTER JOIN client ON sys_doc.client_id = client.client_id LEFT OUTER JOIN 
employee ON sys_doc.handler_id = employee.em_id LEFT OUTER JOIN bm ON sys_doc.bm_id = bm.bm_id LEFT OUTER
 JOIN ck ON sys_doc.ck_id = ck.ck_id}' +
 ' where ' +  ' convert(char(10),sys_doc.doc_date,120 ) >='+''''+@StartData+'''' +   
' and convert(char(10),sys_doc.doc_date,120 ) <= '+''''+@EndData+''''+
 'and ( client.client_name like''%%%'''+' or client.client_pym like ''%%%'''+
'or employee.em_name like ''%%%'''+ 'or employee.em_pym like ''%%%'''+
' or bm.bm_name like ''%%%'''+' or bm.bm_pym like ''%%%'''+ 
'or sys_doc.doc_hao like''%%%'''+' or sys_doc.ck_name like ''%%%'''+')
 AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '+ @YHNO +')
 OR employee.em_code='+ @YHNO +') and sys_doc.del_flag = 0 and sys_doc.red_flag = 0' + @strOrderType + ') as TabTemp)' + @strOrderType  


end
end  
EXEC (@strSql)  
end --->�洢���̽���  






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE     procedure P_JHXSDocSF
---��ȡ�����ţ��������ۺźͳɱ��㷨
@startDate varchar (100),---����ʱ�� yyyy-mm-dd
@endDate varchar (100),---ȥ��-��ʱ����� yyyymmdd
@ZM varchar(20)   --����Ŀ����ǡ�JH�����ߡ�XS��

AS

begin
declare @JH int  --->��ȡ��ǰ�ǵڼ���
declare @jh_hao varchar(100)---->�������Ż������۵���
declare @JHhao varchar(20)---->ǰ��Ϊ0��ͷ������


SELECT @JH= Max ( convert ( Decimal ( 8 , 0 ) , num ) ) From sys_hao Where lx =@ZM And rq =@startDate ---����ǰ�ڼ���
select @JH=@JH +1  
select @JHhao= RIGHT('000'+CAST( convert(varchar(20),@JH)  AS nvarchar(50)),3)--->ǰ��Ϊ0��ͷ����
select  @jh_hao=    @ZM+@endDate + @JHhao---��ƴ�ӽ������������۵���
select  convert(varchar(20),@jh_hao)

select  value from sys_config where name='suanfa'  ---��ȡ�㷨


end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create   procedure KCCX
---���ĳһҳ������---  
@currPage int = 1,   --->��ǰҳҳ��(��top currPage)  
@showColumn varchar(2000) = '*', --->��Ҫ��ѯ���ֶ�(��column1,column2,......)  
@tabName varchar(2000),   --->��Ҫ�鿴�ı���(��from table_name)  
@strCondition varchar(2000) = '', --->��ѯ����(��where condition......) ���ü�where�ؼ���  
@ascColumn varchar(100) = '',  --->������ֶ���(��order by column asc/desc)  
@bitOrderType int = 0,   --->���������(0Ϊ����,1Ϊ����)  
@pkColumn varchar(50) = '',  --->��������  
@pageSize int = 20   --->��ҳ��С  
as  
begin  --->�洢���̿�ʼ  
---�ô洢������Ҫ�õ��ļ�������---  
declare @strTemp varchar(1000)  
declare @strSql varchar(4000)  --->�ô洢�������ִ�е����  
declare @strOrderType varchar(1000) --->�����������(order by column asc/desc)  
begin  
if @bitOrderType = 1  --->@bitOrderType = 1 ��ִ�н���  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' desc'  
    set @strTemp = '<(select min'  
end  
else  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' asc'  
    set @strTemp = '>(select max'  
end  
if @currPage = 1 --->����ǵ�һҳ  
begin  
    if @strCondition != ''  
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + @strOrderType  
 +  '    select top ' + str(@pageSize) + ' ' + @showColumn + ' from  AllKC  where    kc_id  in ( select kc_id from SingelKC  where  '+ @strCondition +' )' + @strOrderType 
    else  
set @strSql =  '   select top ' + str(@pageSize)  + ' ' + @showColumn +  '   from    AllKC  '  + @strOrderType 

end  
else  --->����ҳ  
begin  
    if @strCondition != ''  
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + ' and ' +  
@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
' from ' + @tabName +' where '+ @strCondition + @strOrderType + ') as TabTemp)' + @strOrderType  
+  '   select top ' + str(@pageSize) + ' ' + @showColumn + ' from  AllKC  where    kc_id  in ( '+ '  select kc_id  from ' + @tabName + ' where ' + @strCondition + ' and ' +  
@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
' from ' + @tabName +' where '+ @strCondition + @strOrderType + ') as TabTemp ) '+' )'   + @strOrderType



    else  
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from  AllKC where ' + @pkColumn + @strTemp +  
'(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + ' from  AllKC '  + @strOrderType + ') as TabTemp)' + @strOrderType  
end  
end  
EXEC (@strSql)  
end --->�洢���̽���  



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create   procedure KCCXVer2
---���ĳһҳ������---  
@currPage int = 1,   --->��ǰҳҳ��(��top currPage)  
@showColumn varchar(2000) = '*', --->��Ҫ��ѯ���ֶ�(��column1,column2,......)  
@tabName varchar(2000),   --->��Ҫ�鿴�ı���(��from table_name)  
@strCondition varchar(2000) = '', --->��ѯ����(��where condition......) ���ü�where�ؼ���  
@ascColumn varchar(100) = '',  --->������ֶ���(��order by column asc/desc)  
@bitOrderType int = 0,   --->���������(0Ϊ����,1Ϊ����)  
@pkColumn varchar(50) = '',  --->��������  
@pageSize int = 20   --->��ҳ��С  
as  
begin  --->�洢���̿�ʼ  
---�ô洢������Ҫ�õ��ļ�������---  
declare @strTemp varchar(1000)  
declare @strSql varchar(4000)  --->�ô洢�������ִ�е����  
declare @strOrderType varchar(1000) --->�����������(order by column asc/desc)  
begin  
if @bitOrderType = 1  --->@bitOrderType = 1 ��ִ�н���  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' desc'  
    set @strTemp = '<(select min'  
end  
else  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' asc'  
    set @strTemp = '>(select max'  
end  
if @currPage = 1 --->����ǵ�һҳ  
begin  
if @strCondition != '' 
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName  + ' where ' + @strCondition  + @strOrderType  
else
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName  + @strOrderType  
end 


 
else  --->����ҳ  
begin  
if @strCondition != '' 


set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + ' and ' +  
@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
' from ' + @tabName  + ' where ' + @strCondition  + @strOrderType + ') as TabTemp)' + @strOrderType  
--set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + ' and ' + @pkColumn + @strTemp +  
--'(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + ' from ' +  
--@tabName + @strOrderType + ') as TabTemp)' + @strOrderType  
else
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @pkColumn + @strTemp +  
'(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + ' from ' +  
@tabName + @strOrderType + ') as TabTemp)' + @strOrderType 

end  
end  
EXEC (@strSql)  
end --->�洢���̽���



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





--���Ԥ��

  CREATE     procedure KCYJ
  as
  begin
  declare @strSql varchar(8000)---ִ�����
  begin
  set @strSql='SELECT product.pro_id,product.pic, product.pro_code, product.pro_name, product.pro_pym, product.pro_txm, product.pro_spec,product.pro_model, product.pro_kind, product.pro_color, product.pro_address, product.pro_unit , ( select sum(kc_num)
 from kc ,ck
 where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name and ck.sys_del = 0 ) as kcnum,
 product.pro_max, (( select sum(kc_num) from kc ,ck
 where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name and ck.sys_del = 0) - pro_max ) as num, 
(select sum(kc_desl) from kc ,ck where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name and ck.sys_del = 0) as kc_desl
 FROM product where product.sys_del = 0 and pro_max > 0 and ( select sum(kc_num) from kc ,ck where kc.pro_id = product.pro_id 
and kc.ck_name = ck.ck_name and ck.sys_del = 0) > pro_max and ( product.pro_name like''%%%'''+' or product.pro_spec like ''%%%'''+'
 or product.pro_model like ''%%%'''+' or product.pro_code like ''%%%'''+' or product.pro_color like ''%%%'''+' or product.pro_pym like ''%%%'''+' 
or product.pro_txm like ''%%%'''+'or product.pro_address like ''%%%'''+')'

+' SELECT product.pro_id, product.pic,product.pro_code, product.pro_name, product.pro_pym, product.pro_txm, product.pro_spec, product.pro_model, product.pro_kind, product.pro_color, product.pro_address, product.pro_unit ,
 ( select sum(kc_num) from kc ,ck where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name and ck.sys_del = 0 )
 as kcnum, ( select sum(kc_desl) from kc ,ck where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name and ck.sys_del = 0 )
 as kcdesl, product.pro_min, (pro_min - ( select sum(kc_num) from kc ,ck where kc.pro_id = product.pro_id and kc.ck_name = ck.ck_name 
and ck.sys_del = 0 )) as num 
FROM product where product.sys_del = 0 and pro_min >= 0 and pro_min > ( select sum(kc_num) from kc ,ck where kc.pro_id = product.pro_id 
and kc.ck_name = ck.ck_name and ck.sys_del = 0) and ( product.pro_name like''%%%'''+' or product.pro_spec like ''%%%'''+'
or product.pro_model like ''%%%'''+' or product.pro_code like ''%%%'''+' or product.pro_color like ''%%%'''+' or product.pro_pym like''%%%'''+' 
or product.pro_txm like''%%%'''+' or product.pro_address like ''%%%'''+') '

+' SELECT pro_batch.id,product.pic, pro_batch.pro_id, product.pro_code, product.pro_name, product.pro_spec, product.pro_model, product.pro_color, 
product.pro_period, pro_batch.mx_prodate, pro_batch.mx_bno, pro_batch.ck_name,
 (select sum(num) from pro_batchmx where pro_batchmx.bid = pro_batch.bid and pro_batchmx.ck_name = pro_batch.ck_name) as num,
 (select sum(desl) from pro_batchmx where pro_batchmx.bid = pro_batch.bid and pro_batchmx.ck_name = pro_batch.ck_name) as desl, 
product.pro_period - datediff(day,pro_batch.mx_prodate,getdate()) as days, dateadd(day,pro_period,mx_prodate) as gqdate 
FROM pro_batch, product, ck 
WHERE ( product.pro_id = pro_batch.pro_id ) and ( pro_batch.ck_name = ck.ck_name ) and ( pro_batch.finish_flag <> 2 ) 
AND ck.sys_del = 0 and ( product.sys_del = 0) AND product.pro_period > 0 
and (select sum(num) from pro_batchmx where pro_batchmx.bid = pro_batch.bid 
and pro_batchmx.ck_name = pro_batch.ck_name) > 0 and ( product.pro_name like ''%%%'''+' or product.pro_spec like''%%%'''+'
 or product.pro_model like ''%%%'''+' or product.pro_code like ''%%%'''+' or product.pro_color like ''%%%'''+' or product.pro_pym like ''%%%'''+'
 or product.pro_txm like ''%%%'''+' or product.pro_address like ''%%%'''+') and product.pro_period - datediff(day,pro_batch.mx_prodate,getdate()) <= ''20 '' '
  end
  EXEC(@strSql)
  end
  




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





--��Ʒ��Ϣ

CREATE     procedure Pro_product

@currPage int = 1,   --->��ǰҳҳ��(��top currPage)  
@showColumn varchar(2000)='*', --->��Ҫ��ѯ���ֶ�(��column1,column2,......)  
@tabName varchar(2000)='product',   --->��Ҫ�鿴�ı���(��from table_name)  
@strCondition varchar(2000) ='', --->��ѯ����(��where condition......) ���ü�where�ؼ���  
@ascColumn varchar(100) = '',--->������ֶ���(��order by column asc/desc)  
@bitOrderType int =0,   --->���������(0Ϊ����,1Ϊ����)  
@pkColumn varchar(50) ='pro_id',  --->��������  
@pageSize int = 20   --->��ҳ��С 
as
begin  --->�洢���̿�ʼ  
---�ô洢������Ҫ�õ��ļ�������---  
declare @strTemp varchar(1000)  
declare @strSql varchar(4000)  --->�ô洢�������ִ�е����  
declare @strOrderType varchar(1000) --->�����������(order by column asc/desc)  

begin  
if @bitOrderType = 1  --->@bitOrderType = 1 ��ִ�н���  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' desc'  
    set @strTemp = '<(select min'  
end  

else  
begin  
    set @strOrderType = ' order by ' + @ascColumn + ' asc'  
    set @strTemp = '>(select max'  
end  


if @currPage = 1 --->����ǵ�һҳ  
begin  
if @strCondition != '' 
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName  + ' where ' + @strCondition  + @strOrderType  
else
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName  + @strOrderType  
end  

else  --->����ҳ  
begin  
if @strCondition != '' 


set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + ' and ' +  
@pkColumn + @strTemp + '(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn +  
' from ' + @tabName  + ' where ' + @strCondition  + @strOrderType + ') as TabTemp)' + @strOrderType  
--set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @strCondition + ' and ' + @pkColumn + @strTemp +  
--'(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + ' from ' +  
--@tabName + @strOrderType + ') as TabTemp)' + @strOrderType  
else
set @strSql = 'select top ' + str(@pageSize) + ' ' + @showColumn + ' from ' + @tabName + ' where ' + @pkColumn + @strTemp +  
'(' + @pkColumn + ')' + ' from (select top ' + str((@currPage-1)*@pageSize) + ' ' + @pkColumn + ' from ' +  
@tabName + @strOrderType + ') as TabTemp)' + @strOrderType 

end  
end  
EXEC (@strSql)  
end --->�洢���̽���





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE  procedure Pie
---���ĳһҳ������---  
@currPage varchar(20),
@StartDate varchar(100),
@EndDate varchar(100)
as  
begin  --->�洢���̿�ʼ  
---�ô洢������Ҫ�õ��ļ�������---  

declare @strSql varchar(4000)  --->�ô洢�������ִ�е����  

begin  
set  @strSql='select top  '+@currPage+ '  pro_id,sum(xs_number)num  ,max(pro_name)pro_name ,max(pro_pym)pro_pym,max(pro_txm)pro_txm  from PZT 
where convert(char(10),sys_date,120) >= '+''''+@StartDate+''''+' and convert(char(10),sys_date,120) <= '+''''+@EndDate+''''+' 
group by pro_id
 order by num desc '


end  
EXEC (@strSql)  
end --->�洢���̽���  


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

