
/****** Object:  View [dbo].[AllKC]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[AllKC]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[AllKC]
GO
/****** Object:  View [dbo].[SingelKC]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SingelKC]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[SingelKC]
GO
/****** Object:  View [dbo].[SingelKCVer2]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SingelKCVer2]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[SingelKCVer2]
GO
/****** Object:  View [dbo].[PZT]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[PZT]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[PZT]
GO
/****** Object:  View [dbo].[KCXQView]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[KCXQView]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[KCXQView]
GO
/****** Object:  View [dbo].[YSYF]    Script Date: 09/28/2016 10:01:24 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[YSYF]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[YSYF]
GO
/****** Object:  StoredProcedure [dbo].[DJCX]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DJCX]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[DJCX]
GO
/****** Object:  StoredProcedure [dbo].[P_JHXSDocSF]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[P_JHXSDocSF]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[P_JHXSDocSF]
GO
/****** Object:  StoredProcedure [dbo].[KCCX]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[KCCX]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[KCCX]
GO
/****** Object:  StoredProcedure [dbo].[KCCXVer2]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[KCCXVer2]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[KCCXVer2]
GO
/****** Object:  StoredProcedure [dbo].[KCYJ]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[KCYJ]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[KCYJ]
GO
/****** Object:  StoredProcedure [dbo].[Pie]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[Pie]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[Pie]
GO
/****** Object:  StoredProcedure [dbo].[Pro_product]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[Pro_product]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[Pro_product]
GO
/****** Object:  StoredProcedure [dbo].[P_JH]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[P_JH]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[P_JH]
GO
/****** Object:  StoredProcedure [dbo].[P_MutlMoney]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[P_MutlMoney]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[P_MutlMoney]
GO
/****** Object:  StoredProcedure [dbo].[P_JHHAO]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[P_JHHAO]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[P_JHHAO]
GO
/****** Object:  StoredProcedure [dbo].[proc_GetPageWithTempTable]    Script Date: 09/28/2016 10:01:25 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[proc_GetPageWithTempTable]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[proc_GetPageWithTempTable]
GO





SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create view YSYF (client_id,client_name,sys_del,ps_money,pf_money,ys_money,yf_money)
as
SELECT client.client_id, client.client_name, client.sys_del ,
 isnull(client.ps_money, 0) as ps_money, isnull(client.pf_money, 0) 
as pf_money , isnull(( select sum( case doc_kind when '���۵�' then isnull(ys_more,0) - isnull(ys_less,0) 
when '�����˻�' then -1*(isnull(yf_more,0) - isnull(yf_less,0)) when '�������뵥'
 then isnull(ys_more,0) - isnull(ys_less,0) when '�տ'
 then isnull(ys_more,0) - isnull(ys_less,0) end ) from cw_ysyf where cw_ysyf.client_id = client.client_id),0)
 as ys_money, isnull(( select sum( case doc_kind when '������' 
then isnull(yf_more,0) - isnull(yf_less,0) when '�����˻�'
 then -1*(isnull(ys_more,0) - isnull(ys_less,0)) when '����֧����'
 then isnull(yf_more,0) - isnull(yf_less,0) when '���' 
then isnull(yf_more,0) - isnull(yf_less,0) end )
 from cw_ysyf where cw_ysyf.client_id = client.client_id),0) 
as yf_money FROM client where (client.client_name like '%%%' or client.client_pym like '%%%' or client.client_lxr like '%%%'
 or client.client_tel like '%%%' or client.client_address like '%%%' ) and client.sys_del = 0

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





create     View  PZT (sys_date,pro_name,pro_pym,pro_txm,pro_id,xs_number)---��״ͼ
AS
select convert(char(10),xs.sys_date,120),product.pro_name,product.pro_pym,product.pro_txm,product.pro_code,
case when xsmx.mx_num < 0 then (-1) * xsmx.mx_basenum 
else xsmx.mx_basenum 
end as xs_number 
FROM xs, xsmx, client, product, employee
 WHERE ( xs.xs_hao = xsmx.xs_hao )
 and ( xs.client_id = client.client_id )
 and ( product.pro_id = xsmx.pro_id ) and ( employee.em_id = xs.handler_id ) 
--and convert(char(10),xs.xs_date,120) >= '2016-07-20' 
--and convert(char(10),xs.xs_date,120) <= '2016-07-30' 
and ( product.pro_name like '%%%' or product.pro_spec like '%%%' 
or product.pro_model like '%%%' or product.pro_code like '%%%' or product.pro_color like
 '%%%' or product.pro_pym like '%%%' or product.pro_txm like '%%%' or product.pro_address like '%%%') 
and xs.check_flag = 1 and xs.del_flag = 0 AND (employee.em_code in(select operation from sys_operationright
 where kind = 5 and viewflag = 1 and yh_no = '000000') OR employee.em_code='000000') 





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create    view  SingelKC (kc_id,kc_num,sys_del,inprice,pic,pro_name,ck_name,pro_spec,pro_color,pro_pym,pro_txm,pro_unit,pro_code)
as
select  kc.pro_id,kc_num ,product.sys_del,product.new_inprice, pic ,pro_name ,kc.ck_name,pro_spec,pro_color,pro_pym,pro_txm,pro_unit ,product.pro_code
from kc,product where kc.pro_id=product.pro_id




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create    view  SingelKCVer2 (kc_id,kc_num,sys_del,inprice,pic,pro_name,ck_name,pro_spec,pro_color,pro_pym,pro_txm,pro_unit,pro_code,allnum)
as
SELECT     kc_id, kc_num, sys_del, inprice, pic, pro_name, ck_name, pro_spec, pro_color, pro_pym, pro_txm, pro_unit, pro_code,
                          (SELECT     SUM(kc_num) AS Expr1
                            FROM          dbo.SingelKC AS s
                            WHERE      (k.kc_id = kc_id)
                            GROUP BY kc_id) AS allnum
FROM         dbo.SingelKC AS k




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO








-------����ѯ

CREATE        view  AllKC(kc_id,all_num,pro_name,pro_pym,ck_name,pro_spec,pro_color,pro_txm,pro_unit)
as
select kc.pro_id,sum(kc.kc_num) all_num, product.pro_name,max(product.pro_pym) ,kc.ck_name,max(pro_spec),max(pro_color),max(pro_txm),max(pro_unit)
from kc,product 
where kc.pro_id=product.pro_id 
group by kc.pro_id,pro_name ,kc.ck_name








GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE  View KCXQView (doc_hao,doc_date,handler_name,bm_name,mx_ck,mx_num,pro_name,pro_id,pro_unit)
AS
SELECT jh.jh_hao, jh.sys_date, jh.user_name, jh.bm_name,  jhmx.mx_ck, jhmx.mx_num, product.pro_name ,product.pro_id,product.pro_unit
FROM jh, jhmx, client, product, employee 
WHERE ( jhmx.jh_hao = jh.jh_hao ) and ( jh.client_id = client.client_id ) 
and ( product.pro_id = jhmx.pro_id ) and ( jh.handler_id = employee.em_id )
 and  jh.check_flag = 1 
and jh.del_flag = 0 AND (employee.em_code in
(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '000000' ) 
OR employee.em_code='000000' ) and jhmx.mx_ck in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000' ) 

Union all
SELECT jt.jt_hao,  jt.sys_date, jt.user_name,jt.bm_name,jtmx.mx_ck, jtmx.mx_num, product.pro_name,product.pro_id,product.pro_unit
 FROM client, employee, jt, jtmx, product WHERE ( jtmx.jt_hao = jt.jt_hao ) and ( product.pro_id = jtmx.pro_id ) 
and ( jt.handler_id = employee.em_id ) and ( jt.client_id = client.client_id ) 
 and jt.check_flag = 1 and jt.del_flag = 0 AND (employee.em_code in
(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '000000')
 OR employee.em_code='000000') and jtmx.mx_ck in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000' )
 union all
SELECT xs.xs_hao, xs.sys_date, xs.user_name, xs.bm_name, xsmx.mx_ck,xsmx.mx_num, product.pro_name,product.pro_id,product.pro_unit
FROM xs, xsmx, client, product, employee 
WHERE ( xs.xs_hao = xsmx.xs_hao ) and ( xs.client_id = client.client_id )
 and ( product.pro_id = xsmx.pro_id ) and ( employee.em_id = xs.handler_id ) 
 and xs.check_flag = 1 
and xs.del_flag = 0 AND (employee.em_code in(select operation from sys_operationright where kind = 5 
and viewflag = 1 and yh_no = '000000' ) OR employee.em_code='000000') 
and xsmx.mx_ck in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000' ) 

union all

SELECT xt.xt_hao, xt.sys_date, xt.user_name, xt.bm_name, xtmx.mx_ck, xtmx.mx_num,product.pro_name,product.pro_id,product.pro_unit
 FROM xt, xtmx, client, product, employee 
WHERE ( xtmx.xt_hao = xt.xt_hao ) and ( xt.client_id = client.client_id ) and ( product.pro_id = xtmx.pro_id ) 
and ( xt.handler_id = employee.em_id )  and xt.check_flag = 1 and xt.del_flag = 0
 AND (employee.em_code in(select operation from sys_operationright where kind = 5
 and viewflag = 1 and yh_no = '000000' ) OR employee.em_code='000000' )
 and xtmx.mx_ck in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000' )


union all

SELECT bsby.bsby_hao, bsby.sys_date, bsby.handler_name, bsby.bm_name,  bsby.ck_name,bsbymx.mx_num, product.pro_name,product.pro_id,product.pro_unit
FROM bsby, bsbymx, product , employee
 WHERE ( bsbymx.bsby_hao = bsby.bsby_hao ) and ( product.pro_id = bsbymx.pro_id ) 
and bsby.handler_id = employee.em_id and bsby.check_flag = 1 and bsby.del_flag = 0 
AND (employee.em_code in(select operation from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '000000' )
 OR employee.em_code='000000' ) and bsby.ck_name in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000'  ) 

union all

SELECT  pd.pd_hao, pd.pd_date,  pd.handler_name , '  ' , pd.ck_name,  pdmx.num , product.pro_name ,product.pro_id,product.pro_unit
FROM  pd, pdmx, product 
WHERE ( pdmx.pd_hao = pd.pd_hao ) and ( product.pro_id = pdmx.pro_id ) 
and ( pd.pd_state = 2 ) and pdmx.num <> 0  and pd.pd_state =  2  

union all

SELECT  cr.cr_hao, cr.sys_date , cr.handler_name , cr.bm_name, crmx.mx_ck, crmx.mx_num, product.pro_name  ,product.pro_id,product.pro_unit
   FROM  cr  ,crmx  , product , employee  
 WHERE ( crmx.cr_hao = cr.cr_hao )  and  ( product.pro_id = crmx.pro_id )  and ( employee.em_id = cr.handler_id )
 and cr.check_flag = 1 and cr.del_flag = 0 AND
 (employee.em_code  in(select operation from sys_operationright where kind = 5 
and viewflag = 1 and yh_no = '000000') OR employee.em_code='000000') and crmx.mx_ck 
in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000') 

union all

SELECT  db.db_hao, db.sys_date, db.handler_name , db.bm_name, db.ck_name, dbmx.mx_num,product.pro_name,product.pro_id,product.pro_unit
 FROM  db, dbmx, product ,employee
 WHERE ( dbmx.db_hao = db.db_hao ) and ( product.pro_id = dbmx.pro_id ) 
and db.handler_id = employee.em_id  and db.check_flag = 1 
and db.del_flag = 0 AND (employee.em_code in(select operation
 from sys_operationright where kind = 5 and viewflag = 1 and yh_no = '000000') 
OR employee.em_code='000000') and (db.in_ck in (select ck_name from sys_yh_ck where flag = 1 
and yh_no ='000000') or db.out_ck in (select ck_name from sys_yh_ck where flag = 1 and yh_no = '000000') ) 
  
 




 





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

