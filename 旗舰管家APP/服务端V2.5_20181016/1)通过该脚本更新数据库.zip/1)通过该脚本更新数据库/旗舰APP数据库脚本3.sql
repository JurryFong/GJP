SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE procedure P_JH

------ʵ��jh���ݵĲ����sys_doc���ݵĲ��� ��sys_hao ���ݵĲ���

@jh_time varchar(100),--����ʱ��
@jh_hao varchar(100),--������
---@sys_date varchar(100),
--@jh_date varchar(100),
@ck_name varchar(200),
@bm_name varchar(50),
@client_id varchar(50),
@handler_name varchar(100),
@user_name varchar(100),
@old_doc  varchar(20),
@add_comment varchar(100),
@comment varchar(1000),
@check_flag int,
@back_flag int,
@jhd_hao varchar(10),
@all_money float,
@dis_money float,
@js_account varchar(50),
@js_money float,
--@js_date varchar(100),
@bill_kind varchar(20),
@bill_flag int,
@client_name  varchar(100),
@handler_id varchar(100),
@ck_id varchar(100),
@bm_id varchar(100)


AS 


begin 

declare @JH int --->��ȡ��ǰ�ǵڼ���
declare @Data  varchar(100)---->��ǰ����
--declare @Mind varchar(100)---->�������м�Ĳ��֣�ʵ���Ͼ������ڣ�
--declare @jh_hao varchar(100)---->��������
declare @JHhao varchar(20)---->ǰ��Ϊ0��ͷ������
declare @sys_date varchar(100)
declare @jh_date varchar(100)
declare  @js_date varchar(100)

Select  @Data= Datename(year,GetDate())+'-'+Datename(month,GetDate())+'-'+Datename(day,GetDate())-->��ȡʱ��
-- select  @Mind= CONVERT (nvarchar(12),GETDATE(),112)--->��ȡ��ǰ�Ľ����м�ʱ���
SELECT @JH= Max ( convert ( Decimal ( 8 , 0 ) , num ) ) From sys_hao Where lx ='JH' And rq =@jh_time ---����ǰ�ڼ���
 select @JH=@JH +1  
 select @JHhao= RIGHT('000'+CAST( convert(varchar(20),@JH)  AS nvarchar(50)),3)--->ǰ��Ϊ0��ͷ����
 --select  @jh_hao=    'JH'+@jh_mind + @JHhao---��ƴ�ӽ�����

select @sys_date=@Data
select @jh_date=@Data
select @js_date=@Data



insert jh ( jh_hao, sys_date, jh_date, ck_name, bm_name, client_id, handler_name, user_name, old_doc, add_comment, comment, check_flag, back_flag, jhd_hao, all_money, dis_money, js_account, js_money, js_date, bill_kind, bill_flag, client_name, handler_id, ck_id, bm_id )
          values(@jh_hao, @sys_date,@jh_date,@ck_name,@bm_name,@client_id,@handler_name,@user_name,@old_doc,@add_comment,@comment,@check_flag,@back_flag,@jhd_hao,@all_money,@dis_money,@js_account,@js_money,@js_date,@bill_kind,@bill_flag,@client_name,@handler_id,@ck_id,@bm_id)

-->insert  multi_js ( doc_hao, mjs_account, mjs_money ) VALUES ( @jh_hao, '', 14.991098 )
--->    insert   cw_accountmx ( sub_id, doc_date, doc_hao, doc_kind, overage, money_less ) VALUES ( '013', {ts '2016-12-28 00:00:00.000'}, 'JH20161228005', '������', -4887.043702, 14.991098 )

  insert  sys_doc ( doc_hao, doc_date, doc_kind, client_id, handler_name, comment, user_name, bm_name, ck_name, all_money, dis_money, bm_id, ck_id, handler_id, client_name, del_flag, js_money ) 

   VALUES ( @jh_hao,@sys_date , '������', @client_id, @handler_name, @comment, @user_name, @bm_name, @ck_name, @all_money, @dis_money, @bm_id, @ck_id, @handler_id, @client_name, 0, @js_money )

   insert  sys_hao ( lx , rq , num ) values ( 'JH' , @Data , @JHhao ) 


end










GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





CREATE      procedure P_MutlMoney
--- ʵ�ֲ��� multi_js ��cw_accountmx ����
@doc_hao varchar(100),
@mjs_account varchar(20),
@mjs_money float,
@DJ varchar(20)---������ �������������ߡ����۵���
AS

begin

declare @Data  varchar(100)---->��ǰ����
declare @Cash_Money float

Select  @Data= Datename(year,GetDate())+'-'+Datename(month,GetDate())+'-'+Datename(day,GetDate())-->��ȡʱ��

select @Cash_Money=account_money from cw_account where sub_id =@mjs_account


INSERT  multi_js ( doc_hao, mjs_account, mjs_money ) VALUES (@doc_hao , @mjs_account, @mjs_money )

if @DJ='������'
INSERT  cw_accountmx ( sub_id, doc_date, doc_hao, doc_kind, overage, money_less ) VALUES ( @mjs_account, @Data, @doc_hao, '������', @Cash_Money-@mjs_money, @mjs_money )

else
INSERT  cw_accountmx ( sub_id, doc_date, doc_hao, doc_kind, overage, money_more ) VALUES ( @mjs_account, @Data, @doc_hao, '���۵�', @Cash_Money+@mjs_money, @mjs_money )


select 'YES'

end











GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE     procedure P_JHHAO
---��ȡ�����ţ��������ۺźͳɱ��㷨
@startDate varchar (100),---����ʱ�� yyyy-mm-dd
@endDate varchar (100),---ȥ��-��ʱ����� yyyymmdd
@ZM varchar(20)   --����Ŀ����ǡ�JH�����ߡ�XS��

AS

begin
declare @JH int  --->��ȡ��ǰ�ǵڼ���
declare @jh_hao varchar(100)---->��������
declare @JHhao varchar(20)---->ǰ��Ϊ0��ͷ������


SELECT @JH= Max ( convert ( Decimal ( 8 , 0 ) , num ) ) From sys_hao Where lx =@ZM And rq =@startDate ---����ǰ�ڼ���
select @JH=@JH +1  
select @JHhao= RIGHT('000'+CAST( convert(varchar(20),@JH)  AS nvarchar(50)),3)--->ǰ��Ϊ0��ͷ����
select  @jh_hao=    @ZM+@endDate + @JHhao---��ƴ�ӽ�����
select  convert(varchar(20),@jh_hao)

select  value from sys_config where name='suanfa'


end





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  StoredProcedure [dbo].[proc_GetPageWithTempTable]    Script Date: 12/27/2015 12:38:26 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[proc_GetPageWithTempTable]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[proc_GetPageWithTempTable]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[proc_GetPageWithTempTable]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[proc_GetPageWithTempTable] 
  @TableOrViewName varchar(50),
  @Columns varchar(500),
  @IdentityColumn varchar(50),
  @SortColumn varchar(50),
  @SortDirection varchar(4),
  @SelectedPage int,
  @PageSize int,
  @WhereClause varchar(2000)
  AS 
  
SET NOCOUNT ON
 
DECLARE @SQLQuery varchar(8000), @StartRecord int, @EndRecord int
 
-- Create temporary table
CREATE TABLE #TempTable (
RowNumber int IDENTITY (1, 1),
row_id int )
 
-- Find first record on selected page
SET @StartRecord = (@SelectedPage - 1) * @PageSize + 1
 
-- Find last record on selected page
SET @EndRecord = @SelectedPage * @PageSize
 
-- Check if there is WHERE clause
IF @WhereClause <>  '''' 
  BEGIN
    SET @WhereClause = '' WHERE '' + @WhereClause 
  END
 
-- Build INSERT statement used to populate temporary table
SET @SQLQuery = ''INSERT  #TempTable (row_id) '' +
'' SELECT TOP '' + CAST(@EndRecord AS varchar(20)) + '' '' + 
@IdentityColumn + '' FROM '' + @TableOrViewName + '' '' + 
@WhereClause + ''  ORDER BY '' + @SortColumn + ''  '' + @SortDirection
 
-- Execute statement and populate temp table
EXEC (@SQLQuery)  
 
-- Build SQL query to return only selected page
SET @SQLQuery = N''SELECT '' + @Columns + 
'' FROM #TempTable tmp JOIN '' + @TableOrViewName + 
'' ON row_id = '' + @TableOrViewName + ''.'' + @IdentityColumn +
'' WHERE RowNumber >= '' + CAST(@StartRecord AS varchar(20)) + 
'' AND RowNumber <= '' + CAST(@EndRecord AS varchar(20)) + 
'' ORDER BY RowNumber ''

-- Return selected page
EXEC (@SQLQuery)

-- Delete temporary table
DROP TABLE #TempTable

SET NOCOUNT OFF
' 
END
GO
